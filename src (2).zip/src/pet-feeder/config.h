#ifndef CONFIG_H
#define CONFIG_H

struct FeedTask {
    uint8_t hour;        // 시간
    uint8_t minute;      // 분
    float target_g;      // 목표 무게 (그램 단위)
};

namespace Config { //공통 사용 설정
    namespace WIFI {
        static const char* SSID     = "SK_WiFiGIGAE498_2.4G";       // WiFi SSID
        static const char* PASSWORD = "1704017757";   // WiFi 비밀번호
    }
   
    namespace RFID {
        static constexpr uint8_t RFID_SCK_PIN   = 18;
        static constexpr uint8_t RFID_MISO_PIN  = 19;
        static constexpr uint8_t RFID_MOSI_PIN  = 23;
    }
}

namespace FirstUnit {
            
    static constexpr FeedTask TASKS[] = {
        {8, 0, 120},   // 오전 8시, 120g
        // {22, 00, 80}   // 오후 6시 30분, 80g
    };
 

    static constexpr uint8_t WEIGHT_DOUT_PIN   = 4;
    static constexpr uint8_t WEIGHT_SCK_PIN    = 15;
    static constexpr float   WEIGHT_CAL_FACTOR = 3352.05;

    static constexpr uint8_t RFID_SS_PIN    = 5;
    static constexpr uint8_t RFID_RST_PIN   = 17;
    static constexpr uint8_t RFID_SERVO_PIN = 16;
 

    static const char* AUTH_TAG = { "6c 1e b2 01" }; // 승인된 tag는 1개
    // static constexpr uint8_t AUTH_TAG_COUNT = sizeof(AUTH_TAGS) / sizeof(AUTH_TAGS[0]);
  

    constexpr int FEEDER_MOTOR_STEP = 12;
    constexpr int FEEDER_MOTOR_DIR = 13; // 스텝 모터 제어 핀
    constexpr int FEEDER_MOTOR_EN = 14; // 모터 활성화 핀 (필요시 변경)
    constexpr unsigned long FEEDER_MAX_RUN_MS = 1000000; // 최대 실행 시간 (1000초)

}

#endif